# Task Manager (Android) - Performance tab

## Build ra APK (cách dễ nhất, không cần máy tính cài gì)
1. Tạo repo GitHub mới, upload toàn bộ nội dung thư mục này (giữ cả thư mục `.github`).
2. Vào tab **Actions** -> workflow **Build APK** (tự chạy khi push, hoặc bấm Run workflow).
3. Chạy xong, mở lần chạy đó -> mục **Artifacts** -> tải `TaskManager-apk` -> giải nén ra `app-debug.apk` -> cài.

Hoặc mở bằng Android Studio -> Build > Build APK(s).

## Ghi chú
Android chặn app thường đọc nhiều thông số hệ thống (/proc/stat, tần số CPU, disk, GPU...).
App thử nhiều nguồn, máy nào không cho đọc sẽ hiện N/A hoặc dùng số ước lượng.
