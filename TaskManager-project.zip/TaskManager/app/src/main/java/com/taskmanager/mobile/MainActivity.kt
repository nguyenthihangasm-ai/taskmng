package com.taskmanager.mobile

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private const val BG = 0xFFF3F3F3.toInt()
private const val TXT = 0xFF1A1A1A.toInt()
private const val GRAY = 0xFF5F5F5F.toInt()

class GraphView(ctx: Context, private val r: Res, private val mini: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onMeasure(w: Int, h: Int) {
        if (mini) super.onMeasure(w, h)
        else {
            val ww = MeasureSpec.getSize(w)
            setMeasuredDimension(ww, (ww * 0.52f).toInt())
        }
    }

    private fun blend(c: Int, t: Float): Int {
        val rr = (Color.red(c) * (1 - t) + 255 * t).toInt()
        val gg = (Color.green(c) * (1 - t) + 255 * t).toInt()
        val bb = (Color.blue(c) * (1 - t) + 255 * t).toInt()
        return Color.rgb(rr, gg, bb)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        c.drawColor(Color.WHITE)
        if (!mini) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = d
            p.color = blend(r.line, 0.8f)
            for (i in 1 until 10) {
                c.drawLine(w * i / 10, 0f, w * i / 10, h, p)
                c.drawLine(0f, h * i / 10, w, h * i / 10, p)
            }
        }
        val data = r.hist
        if (data.isNotEmpty()) {
            val step = w / 59f
            val startX = w - (data.size - 1) * step
            path.reset()
            for (i in data.indices) {
                val x = startX + i * step
                val y = h - (data[i] / r.scale).coerceIn(0f, 1f) * (h - d)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val fillPath = Path(path)
            fillPath.lineTo(w, h)
            fillPath.lineTo(startX, h)
            fillPath.close()
            p.style = Paint.Style.FILL
            p.color = r.fill
            c.drawPath(fillPath, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = if (mini) d else 1.5f * d
            p.color = r.line
            c.drawPath(path, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * (if (mini) 1f else 1.5f)
        p.color = r.line
        c.drawRect(p.strokeWidth / 2, p.strokeWidth / 2, w - p.strokeWidth / 2, h - p.strokeWidth / 2, p)
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var sampler: Sampler
    private lateinit var detailBox: LinearLayout
    private lateinit var nav: LinearLayout
    private val cardViews = ArrayList<LinearLayout>()
    private val miniGraphs = ArrayList<GraphView>()
    private val cardTexts = ArrayList<Triple<TextView, TextView, TextView>>()
    private var land = false

    private val tick = object : Runnable {
        override fun run() {
            sampler.sample()
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, color: Int = TXT, bold: Boolean = false, light: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = sp
            setTextColor(color)
            typeface = when {
                bold -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
                light -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                else -> Typeface.create("sans-serif", Typeface.NORMAL)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        sampler = Sampler(applicationContext)
        land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        sampler.sample()
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun buildUi() {
        cardViews.clear(); miniGraphs.clear(); cardTexts.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), 0, dp(8f), 0)
        }
        val menu = tv("\u2630", 22f).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14f), 0, dp(14f), 0)
            setOnClickListener { nav.visibility = if (nav.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        header.addView(menu, LinearLayout.LayoutParams(-2, dp(52f)))
        header.addView(tv("Task Manager", 16f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(tv("\u22EF", 24f).apply { setPadding(dp(14f), 0, dp(14f), 0) })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        // nav panel
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8f), 0, dp(8f), dp(8f))
        }
        val items = listOf(
            "Processes", "Performance", "App history", "Startup apps",
            "Users", "Details", "Services", "Settings"
        )
        for (n in items) {
            val sel = n == "Performance"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                if (sel) background = GradientDrawable().apply { setColor(0xFFE6E6E6.toInt()); cornerRadius = dp(4f).toFloat() }
                setOnClickListener {
                    if (sel) nav.visibility = View.GONE
                    else Toast.makeText(this@MainActivity, "$n: ch\u01B0a l\u00E0m", Toast.LENGTH_SHORT).show()
                }
            }
            val bar = View(this).apply {
                if (sel) background = GradientDrawable().apply { setColor(0xFF0067C0.toInt()); cornerRadius = dp(2f).toFloat() }
            }
            row.addView(bar, LinearLayout.LayoutParams(dp(3f), dp(18f)).apply { leftMargin = dp(2f) })
            row.addView(tv(n, 15f).apply { setPadding(dp(14f), dp(11f), dp(8f), dp(11f)) })
            nav.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        // page title
        root.addView(tv("Performance", 20f, bold = true).apply { setPadding(dp(18f), dp(4f), dp(18f), dp(8f)) })

        // cards
        val cardsCol = LinearLayout(this).apply {
            orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            setPadding(dp(8f), dp(2f), dp(8f), dp(6f))
        }
        Store.all.forEachIndexed { i, r ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
                setOnClickListener { Store.sel = i; refresh() }
            }
            val g = GraphView(this, r, true)
            miniGraphs.add(g)
            card.addView(g, LinearLayout.LayoutParams(dp(64f), dp(46f)))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, 0, 0) }
            val t1 = tv("", 15f)
            val t2 = tv("", 12f, GRAY).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            val t3 = tv("", 12f, GRAY).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            col.addView(t1); col.addView(t2); col.addView(t3)
            card.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            cardViews.add(card)
            cardTexts.add(Triple(t1, t2, t3))
            val lp = if (land) LinearLayout.LayoutParams(-1, -2) else LinearLayout.LayoutParams(dp(210f), -2)
            lp.setMargins(dp(2f), dp(2f), dp(2f), dp(2f))
            cardsCol.addView(card, lp)
        }

        detailBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(24f))
        }
        val detailScroll = ScrollView(this).apply {
            setBackgroundColor(0xFFFBFBFB.toInt())
            addView(detailBox, ViewGroup.LayoutParams(-1, -2))
        }

        if (land) {
            val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            body.addView(ScrollView(this).apply { addView(cardsCol) }, LinearLayout.LayoutParams(0, -1, 0.38f))
            body.addView(detailScroll, LinearLayout.LayoutParams(0, -1, 0.62f))
            root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            root.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(cardsCol)
            }, LinearLayout.LayoutParams(-1, -2))
            root.addView(detailScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        // cards
        Store.all.forEachIndexed { i, r ->
            val (a, b, c) = cardTexts[i]
            a.text = r.title; b.text = r.sub1; c.text = r.sub2
            c.visibility = if (r.sub2.isEmpty()) View.GONE else View.VISIBLE
            cardViews[i].background = GradientDrawable().apply {
                cornerRadius = dp(4f).toFloat()
                if (i == Store.sel) {
                    setColor(Color.WHITE)
                    setStroke(dp(1.5f), 0xFF222222.toInt())
                } else setColor(Color.TRANSPARENT)
            }
            miniGraphs[i].invalidate()
        }
        renderDetail()
    }

    private fun renderDetail() {
        val r = Store.all[Store.sel]
        detailBox.removeAllViews()

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv(r.header, 28f, light = true))
        head.addView(tv(r.model, 14f).apply { gravity = Gravity.END; setPadding(dp(12f), 0, 0, 0) },
            LinearLayout.LayoutParams(0, -2, 1f))
        detailBox.addView(head)

        val lab = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14f), 0, dp(4f)) }
        lab.addView(tv(r.yLabel, 12f, GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        lab.addView(tv(r.yMax, 12f, GRAY))
        detailBox.addView(lab)

        detailBox.addView(GraphView(this, r, false), LinearLayout.LayoutParams(-1, -2))

        val lab2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4f), 0, dp(14f)) }
        lab2.addView(tv("60 seconds", 12f, GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        lab2.addView(tv("0", 12f, GRAY))
        detailBox.addView(lab2)

        val stats = LinearLayout(this).apply {
            orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        }
        val bigBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (row in r.big) {
            val rl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(10f)) }
            for (slot in 0 until 3) {
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                row.getOrNull(slot)?.let {
                    cell.addView(tv(it.first, 13f, GRAY))
                    cell.addView(tv(it.second, 21f, light = true).apply { maxLines = 1 })
                }
                rl.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            bigBox.addView(rl)
        }
        val tableBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((k, v) in r.table) {
            val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3f), 0, dp(3f)) }
            tr.addView(tv(k, 13f, GRAY), LinearLayout.LayoutParams(0, -2, 1f))
            tr.addView(tv(v, 13f), LinearLayout.LayoutParams(0, -2, 0.9f))
            tableBox.addView(tr)
        }
        if (land) {
            stats.addView(bigBox, LinearLayout.LayoutParams(0, -2, 1.2f))
            stats.addView(tableBox, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12f) })
        } else {
            stats.addView(bigBox, LinearLayout.LayoutParams(-1, -2))
            stats.addView(tableBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6f) })
        }
        detailBox.addView(stats)
    }
}
