package com.taskmanager.mobile

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import java.io.File
import java.util.Locale

class Res(val line: Int, val fill: Int) {
    val hist = ArrayList<Float>()
    var scale = 100f
    var title = ""
    var sub1 = ""
    var sub2 = ""
    var header = ""
    var model = ""
    var yLabel = ""
    var yMax = "100%"
    var big: List<List<Pair<String, String>>> = emptyList()
    var table: List<Pair<String, String>> = emptyList()
    fun push(v: Float) {
        hist.add(v)
        if (hist.size > 60) hist.removeAt(0)
    }
}

object Store {
    val cpu = Res(0xFF1B93C9.toInt(), 0xFFBFE5F5.toInt())
    val mem = Res(0xFF5B6FD6.toInt(), 0xFFC9D0F2.toInt())
    val disk = Res(0xFF4EA72B.toInt(), 0xFFCFE9C3.toInt())
    val wifi = Res(0xFFC27A28.toInt(), 0xFFF1DCC3.toInt())
    val gpu = Res(0xFF7B3FB5.toInt(), 0xFFDCCFEE.toInt())
    val all = listOf(cpu, mem, disk, wifi, gpu)
    var sel = 0
}

private fun f(fmt: String, vararg a: Any) = String.format(Locale.US, fmt, *a)

class Sampler(private val ctx: Context) {
    private val ncpu = Runtime.getRuntime().availableProcessors()
    private var prevWall = SystemClock.elapsedRealtime()
    private var prevTotal = -1L
    private var prevIdle = 0L
    private var prevProc = Process.getElapsedCpuTime()
    private var prevRx = TrafficStats.getTotalRxBytes()
    private var prevTx = TrafficStats.getTotalTxBytes()
    private val prevTicks = HashMap<String, Long>()

    @Volatile private var gpuRenderer = ""
    @Volatile private var gpuVendor = ""
    @Volatile private var gpuVersion = ""

    private val cpuName: String = detectCpuName()
    private val cache: Triple<String, String, String> = cacheSizes()
    private val virt = if (File("/dev/kvm").exists()) "Enabled" else "Disabled"

    init {
        Thread { readGpuInfo() }.start()
    }

    private fun read(p: String): String? = try {
        File(p).readText().trim()
    } catch (e: Exception) {
        null
    }

    // ---------------------------------------------------------------- CPU
    private fun detectCpuName(): String {
        if (Build.VERSION.SDK_INT >= 31) {
            val m = Build.SOC_MODEL
            if (m.isNotBlank() && m != "unknown") return "${Build.SOC_MANUFACTURER} $m"
        }
        read("/proc/cpuinfo")?.lineSequence()
            ?.firstOrNull { it.startsWith("Hardware") }
            ?.substringAfter(":")?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { return it }
        return Build.HARDWARE
    }

    private fun parseKb(s: String): Long {
        val n = s.filter { it.isDigit() }.toLongOrNull() ?: return 0
        return if (s.uppercase().contains("M")) n * 1024 else n
    }

    private fun fmtKb(kb: Long) = when {
        kb <= 0 -> "N/A"
        kb >= 1024 -> f("%.1f MB", kb / 1024.0)
        else -> "$kb KB"
    }

    private fun cacheSizes(): Triple<String, String, String> {
        var l1 = 0L; var l2 = 0L; var l3 = 0L
        for (c in 0 until ncpu) for (i in 0..7) {
            val b = "/sys/devices/system/cpu/cpu$c/cache/index$i"
            val lvl = read("$b/level")?.toIntOrNull() ?: continue
            val kb = parseKb(read("$b/size") ?: continue)
            when (lvl) {
                1 -> l1 += kb
                2 -> l2 += kb
                3 -> if (kb > l3) l3 = kb
            }
        }
        return Triple(fmtKb(l1), fmtKb(l2), fmtKb(l3))
    }

    private fun freqs(name: String): List<Long> = (0 until ncpu).mapNotNull {
        read("/sys/devices/system/cpu/cpu$it/cpufreq/$name")?.toLongOrNull()
    }

    private fun pctFromProcStat(): Float? {
        val line = read("/proc/stat")?.lineSequence()?.firstOrNull { it.startsWith("cpu ") } ?: return null
        val p = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 4) return null
        val idle = p[3] + p.getOrElse(4) { 0L }
        val total = p.take(8).sum()
        var res: Float? = null
        if (prevTotal >= 0 && total > prevTotal) {
            res = (1f - (idle - prevIdle).toFloat() / (total - prevTotal)) * 100f
        }
        prevTotal = total
        prevIdle = idle
        return res?.coerceIn(0f, 100f)
    }

    private fun uptime(): String {
        var s = SystemClock.elapsedRealtime() / 1000
        val d = s / 86400; s %= 86400
        val h = s / 3600; s %= 3600
        val m = s / 60; s %= 60
        return f("%d:%02d:%02d:%02d", d, h, m, s)
    }

    private fun sampleCpu(dt: Float) {
        val cur = freqs("scaling_cur_freq")
        val mx = freqs("cpuinfo_max_freq")
        val mn = freqs("cpuinfo_min_freq")
        val curAvg = if (cur.isNotEmpty()) cur.average() else null
        val procNow = Process.getElapsedCpuTime()
        val ownPct = ((procNow - prevProc) / (dt * 1000f * ncpu) * 100f).coerceIn(0f, 100f)
        prevProc = procNow

        var pct = pctFromProcStat()
        if (pct == null && curAvg != null && mx.isNotEmpty()) {
            val hi = mx.average()
            val lo = if (mn.isNotEmpty()) mn.average() else 0.0
            if (hi > lo) pct = ((curAvg - lo) / (hi - lo) * 100.0).toFloat().coerceIn(0f, 100f)
        }
        if (pct == null) pct = ownPct

        // processes / threads / handles (only what Android lets this app see)
        val dirs = File("/proc").listFiles()?.filter { d -> d.name.all { it.isDigit() } } ?: emptyList()
        var procs = dirs.size
        var threads = 0
        var handles = 0
        val rx = Regex("Threads:\\s+(\\d+)")
        for (d in dirs) {
            read("${d.path}/status")?.let { threads += rx.find(it)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
            handles += File("${d.path}/fd").list()?.size ?: 0
        }
        if (procs < 2) {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            procs = maxOf(procs, am.runningAppProcesses?.size ?: 0)
        }
        if (threads == 0) threads = Thread.getAllStackTraces().size

        val speed = if (curAvg != null) f("%.2f GHz", curAvg / 1e6) else "N/A"
        val maxSpeed = if (mx.isNotEmpty()) f("%.2f GHz", mx.max() / 1e6) else "N/A"
        val p = pct.toInt()

        val r = Store.cpu
        r.push(pct)
        r.title = "CPU"
        r.sub1 = if (curAvg != null) "$p%  $speed" else "$p%"
        r.sub2 = ""
        r.header = "CPU"
        r.model = cpuName
        r.yLabel = "% Utilization"
        r.yMax = "100%"
        r.big = listOf(
            listOf("Utilization" to "$p%", "Speed" to speed),
            listOf("Processes" to "$procs", "Threads" to "$threads", "Handles" to "$handles"),
            listOf("Up time" to uptime())
        )
        r.table = listOf(
            "Max speed:" to maxSpeed,
            "Sockets:" to "1",
            "Cores:" to "$ncpu",
            "Logical processors:" to "$ncpu",
            "Virtualization:" to virt,
            "L1 cache:" to cache.first,
            "L2 cache:" to cache.second,
            "L3 cache:" to cache.third
        )
    }

    // ------------------------------------------------------------- Memory
    private fun sampleMem() {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val gb = 1024.0 * 1024 * 1024
        val total = mi.totalMem.toDouble()
        val avail = mi.availMem.toDouble()
        val used = total - avail
        val pct = (used / total * 100).toFloat()

        val info = HashMap<String, Long>()
        read("/proc/meminfo")?.lines()?.forEach {
            val k = it.substringBefore(":")
            val v = it.substringAfter(":").trim().substringBefore(" ").toLongOrNull()
            if (v != null) info[k] = v * 1024
        }
        val cached = (info["Cached"] ?: 0L) / gb
        val swapT = (info["SwapTotal"] ?: 0L) / gb
        val swapU = swapT - (info["SwapFree"] ?: 0L) / gb

        val r = Store.mem
        r.push(pct)
        r.title = "Memory"
        r.sub1 = f("%.1f/%.1f GB (%d%%)", used / gb, total / gb, pct.toInt())
        r.sub2 = ""
        r.header = "Memory"
        r.model = f("%.1f GB", total / gb)
        r.yLabel = "Memory usage"
        r.yMax = f("%.1f GB", total / gb)
        r.big = listOf(
            listOf("In use" to f("%.1f GB", used / gb), "Available" to f("%.1f GB", avail / gb)),
            listOf("Cached" to f("%.1f GB", cached), "Swap used" to f("%.1f GB", swapU))
        )
        r.table = listOf(
            "Total RAM:" to f("%.1f GB", total / gb),
            "Swap total:" to f("%.1f GB", swapT),
            "Low memory:" to if (mi.lowMemory) "Yes" else "No"
        )
    }

    // --------------------------------------------------------------- Disk
    private fun diskActivity(now: Long): Float? {
        val txt = read("/proc/diskstats") ?: return null
        var best: Float? = null
        val re = Regex("^(sd[a-z]+|mmcblk\\d+|nvme\\d+n\\d+|vd[a-z]+)$")
        for (l in txt.lines()) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 13 || !re.matches(p[2])) continue
            val ticks = p[12].toLongOrNull() ?: continue
            val prev = prevTicks[p[2]]
            prevTicks[p[2]] = ticks
            if (prev != null) {
                val v = ((ticks - prev) / 10f).coerceIn(0f, 100f) // ticks(ms)/1000ms*100
                if (best == null || v > best) best = v
            }
        }
        return best
    }

    private fun sampleDisk(now: Long) {
        val st = StatFs(Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024 * 1024
        val total = st.totalBytes.toDouble()
        val free = st.availableBytes.toDouble()
        val used = total - free
        val usedPct = (used / total * 100).toInt()
        val act = diskActivity(now)

        val r = Store.disk
        r.push(act ?: 0f)
        r.title = "Disk 0 (Internal)"
        r.sub1 = "Flash storage"
        r.sub2 = if (act != null) "${act.toInt()}%" else "Used $usedPct%"
        r.header = "Disk 0 (Internal)"
        r.model = f("%.0f GB", total / gb)
        r.yLabel = "Active time"
        r.yMax = "100%"
        r.big = listOf(
            listOf("Active time" to (if (act != null) "${act.toInt()}%" else "N/A"),
                "Used" to f("%.1f GB", used / gb)),
            listOf("Free" to f("%.1f GB", free / gb), "Used %" to "$usedPct%")
        )
        r.table = listOf(
            "Capacity:" to f("%.1f GB", total / gb),
            "Type:" to "Flash (internal)",
            "Path:" to Environment.getDataDirectory().path
        )
    }

    // ------------------------------------------------------------ Network
    private fun fmtBps(v: Double, unitFrom: Double): String = when {
        unitFrom >= 1e9 -> f("%.1f", v / 1e9)
        unitFrom >= 1e6 -> f("%.1f", v / 1e6)
        else -> f("%.1f", v / 1e3)
    }

    private fun unitName(v: Double) = when {
        v >= 1e9 -> "Gbps"
        v >= 1e6 -> "Mbps"
        else -> "Kbps"
    }

    private fun sampleNet(dt: Float) {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val rxBps = if (rx >= 0 && prevRx >= 0) (rx - prevRx) * 8.0 / dt else 0.0
        val txBps = if (tx >= 0 && prevTx >= 0) (tx - prevTx) * 8.0 / dt else 0.0
        prevRx = rx
        prevTx = tx

        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val name = when {
            caps == null -> "Not connected"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Network"
        }

        val r = Store.wifi
        r.push((rxBps + txBps).toFloat())
        val mx = r.hist.maxOrNull() ?: 0f
        val steps = listOf(1e5f, 1e6f, 1e7f, 1e8f, 1e9f, 1e10f)
        r.scale = steps.firstOrNull { it >= mx } ?: steps.last()
        val sLabel = when {
            r.scale >= 1e9f -> f("%.0f Gbps", r.scale / 1e9)
            r.scale >= 1e6f -> f("%.0f Mbps", r.scale / 1e6)
            else -> f("%.0f Kbps", r.scale / 1e3)
        }
        val big = maxOf(rxBps, txBps)
        val u = unitName(big)
        r.title = name
        r.sub1 = name
        r.sub2 = "S: ${fmtBps(txBps, big)} R: ${fmtBps(rxBps, big)} $u"
        r.header = name
        r.model = name
        r.yLabel = "Throughput"
        r.yMax = sLabel
        r.big = listOf(
            listOf("Send" to "${fmtBps(txBps, txBps)} ${unitName(txBps)}",
                "Receive" to "${fmtBps(rxBps, rxBps)} ${unitName(rxBps)}")
        )
        r.table = listOf(
            "Connection type:" to name,
            "Total sent:" to f("%.1f MB", maxOf(tx, 0L) / 1048576.0),
            "Total received:" to f("%.1f MB", maxOf(rx, 0L) / 1048576.0)
        )
    }

    // ---------------------------------------------------------------- GPU
    private fun readGpuInfo() {
        try {
            val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val v = IntArray(2)
            EGL14.eglInitialize(d, v, 0, v, 1)
            val attr = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0)
            val ctxGl = EGL14.eglCreateContext(
                d, cfgs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            val surf = EGL14.eglCreatePbufferSurface(
                d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
            )
            EGL14.eglMakeCurrent(d, surf, surf, ctxGl)
            gpuRenderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: ""
            gpuVendor = GLES20.glGetString(GLES20.GL_VENDOR) ?: ""
            gpuVersion = GLES20.glGetString(GLES20.GL_VERSION) ?: ""
            EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(d, surf)
            EGL14.eglDestroyContext(d, ctxGl)
            EGL14.eglTerminate(d)
        } catch (e: Throwable) {
        }
    }

    private fun gpuPercent(): Float? {
        for (p in listOf("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", "/sys/kernel/gpu/gpu_busy")) {
            read(p)?.let { s -> Regex("\\d+").find(s)?.value?.toFloatOrNull()?.let { return it.coerceIn(0f, 100f) } }
        }
        read("/sys/class/kgsl/kgsl-3d0/gpubusy")?.split(Regex("\\s+"))?.let {
            val b = it.getOrNull(0)?.toFloatOrNull()
            val t = it.getOrNull(1)?.toFloatOrNull()
            if (b != null && t != null && t > 0) return (b / t * 100f).coerceIn(0f, 100f)
        }
        File("/sys/class/devfreq").listFiles()?.forEach { d ->
            if (d.name.contains("mali") || d.name.contains("gpu")) {
                read("${d.path}/load")?.let { s ->
                    Regex("^\\d+").find(s)?.value?.toFloatOrNull()?.let { return it.coerceIn(0f, 100f) }
                }
            }
        }
        return null
    }

    private fun sampleGpu() {
        val pct = gpuPercent()
        val r = Store.gpu
        r.push(pct ?: 0f)
        val name = gpuRenderer.ifEmpty { "GPU" }
        r.title = "GPU 0"
        r.sub1 = name
        r.sub2 = "${(pct ?: 0f).toInt()}%"
        r.header = "GPU 0"
        r.model = name
        r.yLabel = "% Utilization"
        r.yMax = "100%"
        r.big = listOf(
            listOf("Utilization" to (if (pct != null) "${pct.toInt()}%" else "N/A"))
        )
        r.table = listOf(
            "Vendor:" to gpuVendor.ifEmpty { "N/A" },
            "Renderer:" to name,
            "OpenGL ES:" to gpuVersion.ifEmpty { "N/A" }
        )
    }

    // -------------------------------------------------------------- Tick
    fun sample() {
        val now = SystemClock.elapsedRealtime()
        val dt = (now - prevWall).coerceAtLeast(1) / 1000f
        prevWall = now
        sampleCpu(dt)
        sampleMem()
        sampleDisk(now)
        sampleNet(dt)
        sampleGpu()
    }
}
